import { Component } from '@angular/core';

@Component({
  selector: 'app-home-comp',
  templateUrl: './home-comp.component.html',
  styleUrl: './home-comp.component.css'
})
export class HomeCompComponent {

}
