export interface GetClaimStatus{
    month?:string;
    year?:Number;
}