export interface PaymentReport{
    month: string;
    totalCost?: Number;
}