export interface ClaimReport {

    status?: string;
    totalCount?: Number;
}