﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRDA_BAL.DTOs
{
    public class ClaimPaymentReportDTO
    {
        public string Month { get; set; }
        public int TotalCost { get; set; }
    }
}
